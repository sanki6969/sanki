const { MongoClient } = require('mongodb');

// Connection URL and Database Name
const url = 'mongodb://127.0.0.1:27017';
const dbName = 'practDB';

async function main() {
  const client = new MongoClient(url);

  try {
    await client.connect();
    console.log('Connected successfully to MongoDB');

    const db = client.db(dbName);
    const collection = db.collection('students');

    // c. Insert a record
    const insertResult = await collection.insertOne({
      name: 'Priya',
      course: 'MongoDB with Node',
      marks: 92
    });
    console.log('Inserted record:', insertResult.insertedId);

    // d. View records
    const allStudents = await collection.find({}).toArray();
    console.log('All students:', allStudents);

    // e. Update a record
    const updateResult = await collection.updateOne(
      { name: 'Priya' },
      { $set: { marks: 99 } }
    );
    console.log('Updated count:', updateResult.modifiedCount);

    // e. Delete a record
    const deleteResult = await collection.deleteOne({ name: 'Priya' });
    console.log('Deleted count:', deleteResult.deletedCount);

    // View final data
    const finalStudents = await collection.find({}).toArray();
    console.log('Final students list:', finalStudents);

  } catch (err) {
    console.error('Error:', err);
  } finally {
    await client.close();
    console.log('Connection closed');
  }
}

main();