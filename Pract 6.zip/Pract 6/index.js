const express = require('express');
const app = express();
const PORT = 3000;

app.get('/', (req, res) => {
  console.log('Home route was accessed');
  res.send('<h1>Welcome to my Express Server!</h1>');
});

app.get('/about', (req, res) => {
  console.log('About route was accessed');
  res.send('<h2>This is the About Page</h2>');
});

app.get('/api/data', (req, res) => {
  console.log('API data route was accessed');
  res.json({
    name: 'Student',
    course: 'Node.js and Express',
    status: 'Learning Successful'
  });
});

app.get('/contact', (req, res) => {
  console.log('Contact route was accessed');
  res.send('Contact us at: example@email.com');
});

app.listen(PORT, () => {
  console.log(`Server is running successfully on http://localhost:${PORT}`);
});