import React, { useEffect, useState } from "react";
import axios from "axios";


function Users(){

const [users,setUsers] = useState([]);

const [search,setSearch] = useState("");


// Fetch API data

useEffect(()=>{

axios
.get("https://jsonplaceholder.typicode.com/users")

.then(response=>{

setUsers(response.data);

});

},[]);



return(

<div>

<h1>
Users List
</h1>


<input

type="text"

placeholder="Search users"

value={search}

onChange={(e)=>setSearch(e.target.value)}

/>


<table border="1">

<thead>

<tr>

<th>
Name
</th>

<th>
Email
</th>

<th>
City
</th>

</tr>

</thead>


<tbody>


{

users

.filter((user)=>

user.name
.toLowerCase()
.includes(search.toLowerCase())

)


.map((user)=>(


<tr key={user.id}>

<td>
{user.name}
</td>

<td>
{user.email}
</td>

<td>
{user.address.city}
</td>


</tr>


))


}


</tbody>


</table>


</div>

);

}


export default Users;