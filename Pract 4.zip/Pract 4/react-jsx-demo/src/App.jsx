import React, { useState } from "react";
import "./App.css";

// Component 1: Header
function Header(props) {
  return <h1>{props.title}</h1>;
}

// Component 2: User Profile (using props)
function UserProfile({ name, age }) {
  return (
    <div>
      <h2>User Profile</h2>
      <p>Name: {name}</p>
      <p>Age: {age}</p>
    </div>
  );
}

// Component 3: Form Component
function UserForm() {
  const [input, setInput] = useState("");
  const [displayName, setDisplayName] = useState("");

  function handleSubmit(e) {
    e.preventDefault();
    setDisplayName(input);
    setInput("");
  }

  return (
    <div>
      <h2>User Input Form</h2>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Enter your name"
        />

        <button type="submit">Submit</button>
      </form>

      <p>
        Entered Name: <b>{displayName}</b>
      </p>
    </div>
  );
}

// Component 4: Counter Component
function Counter() {
  const [count, setCount] = useState(0);

  return (
    <div>
      <h2>Counter</h2>
      <p>Count: {count}</p>

      <button onClick={() => setCount(count + 1)}>
        Increase
      </button>

      <button onClick={() => setCount(count - 1)}>
        Decrease
      </button>
    </div>
  );
}

// Component 5: Todo List Component
function TodoList() {
  const [items, setItems] = useState([
    "Learn React",
    "Practice Components",
    "Build Projects"
  ]);

  const [task, setTask] = useState("");

  function addTask() {
    if (task !== "") {
      setItems([...items, task]);
      setTask("");
    }
  }

  return (
    <div>
      <h2>Todo List</h2>

      <input
        value={task}
        onChange={(e) => setTask(e.target.value)}
        placeholder="Add task"
      />

      <button onClick={addTask}>
        Add
      </button>

      <ul>
        {items.map((item, index) => (
          <li key={index}>
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
}


// Main Component
function App() {
  return (
    <div className="App">

      <Header title="React Components Demo" />

      <UserProfile
        name="John"
        age="21"
      />

      <UserForm />

      <Counter />

      <TodoList />

    </div>
  );
}

export default App;